package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.AdoptionRequestDTO;
import com.example.demo.model.LoginRequest;
import com.example.demo.model.User;
import com.example.demo.service.UserService;

import jakarta.validation.Valid;

@RestController
@Validated
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService; // Injecting the UserService dependency

    @PostMapping("/register")
    public User registerUser(@Valid @RequestBody User user) {
        // Register a new user
        return userService.registerUser(user);
    }

    @PostMapping("/login")
    public User loginUser(@Valid @RequestBody LoginRequest loginRequest) {
        // Log in a user with the provided credentials
        return userService.loginUser(loginRequest);
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        // Retrieve a user by their ID
        User user = userService.getUserById(id);
        return ResponseEntity.ok(user);
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@Valid @PathVariable Long id, @RequestBody User updatedUser) {
        // Update the details of an existing user
        User user = userService.updateUser(id, updatedUser);
        return ResponseEntity.ok(user);
    }

    @GetMapping("/{id}/adoption-requests")
    public ResponseEntity<List<AdoptionRequestDTO>> getAdoptionRequestsForUser(@PathVariable Long id) {
        // Get adoption requests for a specific user
        List<AdoptionRequestDTO> requests = userService.getAdoptionRequestsForUser(id);
        return ResponseEntity.ok(requests);
    }
}