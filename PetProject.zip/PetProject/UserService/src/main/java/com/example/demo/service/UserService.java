package com.example.demo.service;

import java.util.List;

import com.example.demo.model.AdoptionRequestDTO;
import com.example.demo.model.LoginRequest;
import com.example.demo.model.User;

public interface UserService {

    // Register a new user
    User registerUser(User user);

    // Log in a user with the provided credentials
    User loginUser(LoginRequest loginRequest);

    // Retrieve a user by their ID
    User getUserById(Long id);

    // Update the details of an existing user
    User updateUser(Long id, User updatedUser);

    // Get adoption requests for a specific user
    List<AdoptionRequestDTO> getAdoptionRequestsForUser(Long id);
}