package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.client.AdoptionRequestClient;
import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.model.AdoptionRequestDTO;
import com.example.demo.model.LoginRequest;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository; // Injecting the UserRepository dependency

    @Autowired
    private AdoptionRequestClient adoptionRequestClient; // Injecting the AdoptionRequestClient dependency

    @Override
    public User registerUser(User user) {
        // Save the user to the database
        return userRepository.save(user);
    }

    @Override
    public User loginUser(LoginRequest loginRequest) {
        // Find the user by username
        Optional<User> user = userRepository.findByUsername(loginRequest.getUsername());
        // Check if the user exists and the password matches
        if (user.isEmpty() || !user.get().getPassword().equals(loginRequest.getPassword())) {
            throw new InvalidCredentialsException("Invalid username or password");
        }
        // Return the user if credentials are valid
        return user.get();
    }

    @Override
    public User getUserById(Long id) throws InvalidCredentialsException {
        // Find the user by ID or throw an exception if not found
        return userRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("User not found"));
    }

    @Override
    public User updateUser(Long id, User updatedUser) {
        // Get the existing user by ID
        User user = getUserById(id);

        // Update the user's details if provided
        if (updatedUser.getUsername() != null) {
            user.setUsername(updatedUser.getUsername());
        }
        if (updatedUser.getEmail() != null) {
            user.setEmail(updatedUser.getEmail());
        }
        if (updatedUser.getPassword() != null) {
            user.setPassword(updatedUser.getPassword());
        }
        // Save the updated user to the database
        return userRepository.save(user);
    }

    @Override
    public List<AdoptionRequestDTO> getAdoptionRequestsForUser(Long userId) throws InvalidCredentialsException {
        // Get the adoption requests for the user from the AdoptionRequestClient
        return adoptionRequestClient.getRequestsByUserId(userId);
    }
}