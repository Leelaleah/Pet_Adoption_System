package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.model.AdoptionRequest;
import com.example.demo.repository.AdoptionRequestRepository;

@Service
public class AdoptionRequestServiceImpl implements AdoptionRequestService {

    @Autowired
    private AdoptionRequestRepository adoptionRequestRepository; // Injecting the AdoptionRequestRepository dependency

    @Override
    public AdoptionRequest addAdoptionRequest(AdoptionRequest request, Long petId, Long userId) {
        // Set the pet ID and user ID for the adoption request
        request.setPetId(petId);
        request.setUserId(userId);
        // Save the adoption request to the database
        return adoptionRequestRepository.save(request);
    }

    @Override
    public AdoptionRequest updateAdoptionRequest(Long id, AdoptionRequest requestDetails) {
        // Get the existing adoption request by ID
        AdoptionRequest request = getRequestById(id);
        // Update the status of the adoption request
        request.setStatus(requestDetails.getStatus());
        // Save the updated adoption request to the database
        return adoptionRequestRepository.save(request);
    }

    @Override
    public void deleteAdoptionRequest(Long id) {
        // Delete the adoption request by its ID
        adoptionRequestRepository.deleteById(id);
    }

    @Override
    public List<AdoptionRequest> getAllRequests() throws InvalidCredentialsException {
        // Get a list of all adoption requests
        return adoptionRequestRepository.findAll();
    }

    @Override
    public List<AdoptionRequest> getRequestsByPetId(Long petId) throws InvalidCredentialsException {
        // Get adoption requests for a specific pet by pet ID
        return adoptionRequestRepository.findByPetId(petId);
    }

    @Override
    public List<AdoptionRequest> getRequestsByUserId(Long userId) throws InvalidCredentialsException {
        // Get adoption requests for a specific user by user ID
        return adoptionRequestRepository.findByUserId(userId);
    }

    @Override
    public AdoptionRequest getRequestById(Long id) throws InvalidCredentialsException {
        // Get an adoption request by its ID or throw an exception if not found
        return adoptionRequestRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Adoption request not found"));
    }
}