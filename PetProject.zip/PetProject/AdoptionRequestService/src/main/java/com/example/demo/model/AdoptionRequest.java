package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "adoption_request_table")
public class AdoptionRequest {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Unique identifier for the adoption request

    @NotNull(message = "Pet ID is mandatory")
    @Column(nullable = false)
    private Long petId; // ID of the pet being adopted

    @NotNull(message = "User ID is mandatory")
    @Column(nullable = false)
    private Long userId; // ID of the user making the adoption request

    @NotBlank(message = "Status is mandatory")
    @Column(nullable = false)
    private String status; // Status of the adoption request (e.g., Pending, Approved, Rejected)
    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPetId() {
        return petId;
    }

    public void setPetId(Long petId) {
        this.petId = petId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Constructors

    public AdoptionRequest(Long id, Long petId, Long userId, String status) {
        this.id = id;
        this.petId = petId;
        this.userId = userId;
        this.status = status;
    }

    public AdoptionRequest() {
        // Default constructor
    }
}