package com.example.demo.service;

import java.util.List;

import com.example.demo.model.AdoptionRequest;

public interface AdoptionRequestService {

    // Add a new adoption request
    AdoptionRequest addAdoptionRequest(AdoptionRequest request, Long petId, Long userId);

    // Update an existing adoption request's details
    AdoptionRequest updateAdoptionRequest(Long id, AdoptionRequest requestDetails);

    // Delete an adoption request by its ID
    void deleteAdoptionRequest(Long id);

    // Get a list of all adoption requests
    List<AdoptionRequest> getAllRequests();

    // Get adoption requests for a specific pet by pet ID
    List<AdoptionRequest> getRequestsByPetId(Long petId);

    // Get adoption requests for a specific user by user ID
    List<AdoptionRequest> getRequestsByUserId(Long userId);

    // Get an adoption request by its ID
    AdoptionRequest getRequestById(Long id);
}