package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.AdoptionRequest;
import com.example.demo.service.AdoptionRequestService;

import jakarta.validation.Valid;

@RestController
@Validated
@RequestMapping("/adoption-requests")
public class AdoptionRequestController {

	@Autowired
	private AdoptionRequestService adoptionRequestService;

	@PostMapping("pet/{petId}/user/{userId}")
	public AdoptionRequest addAdoptionRequest(@Valid @RequestBody AdoptionRequest request, @PathVariable Long petId,
			@PathVariable Long userId) {
		return adoptionRequestService.addAdoptionRequest(request, petId, userId);
	}

	@PutMapping("/{id}")
	public AdoptionRequest updateAdoptionRequest(@Valid @PathVariable Long id, @RequestBody AdoptionRequest requestDetails) {
		return adoptionRequestService.updateAdoptionRequest(id, requestDetails);
	}

	@DeleteMapping("/{id}")
	public void deleteAdoptionRequest(@PathVariable Long id) {
		adoptionRequestService.deleteAdoptionRequest(id);
	}

	@GetMapping
	public List<AdoptionRequest> getAllRequests() {
		return adoptionRequestService.getAllRequests();
	}

	@GetMapping("/pet/{petId}")
	public List<AdoptionRequest> getRequestsByPetId(@PathVariable Long petId) {
		return adoptionRequestService.getRequestsByPetId(petId);
	}

	@GetMapping("/user/{userId}")
	public List<AdoptionRequest> getRequestsByUserId(@PathVariable Long userId) {
		return adoptionRequestService.getRequestsByUserId(userId);
	}

	@GetMapping("/{id}")
	public ResponseEntity<AdoptionRequest> getRequestById(@PathVariable Long id) {
		AdoptionRequest request = adoptionRequestService.getRequestById(id);
		return ResponseEntity.ok(request);
	}
}
