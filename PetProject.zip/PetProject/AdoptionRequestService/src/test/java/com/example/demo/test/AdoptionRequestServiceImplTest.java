package com.example.demo.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.model.AdoptionRequest;
import com.example.demo.repository.AdoptionRequestRepository;
import com.example.demo.service.AdoptionRequestServiceImpl;

public class AdoptionRequestServiceImplTest {

	@Mock
	private AdoptionRequestRepository adoptionRequestRepository;

	@InjectMocks
	private AdoptionRequestServiceImpl adoptionRequestService;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testAddAdoptionRequest() {
		AdoptionRequest mockRequest = new AdoptionRequest();
		mockRequest.setPetId(1L);
		mockRequest.setUserId(1L);

		when(adoptionRequestRepository.save(mockRequest)).thenReturn(mockRequest);

		AdoptionRequest addedRequest = adoptionRequestService.addAdoptionRequest(mockRequest, 1L, 1L);

		assertEquals(1L, addedRequest.getPetId());
		assertEquals(1L, addedRequest.getUserId());
	}

	@Test
	void testDeleteAdoptionRequest() {
		// Call the deleteAdoptionRequest method
		adoptionRequestService.deleteAdoptionRequest(1L);

		// Verify that the adoptionRequestRepository.deleteById method was called with
		// the correct ID
		verify(adoptionRequestRepository).deleteById(1L);
	}

	@Test
	void testGetAllRequests() throws InvalidCredentialsException {
		// Create a list of mock adoption requests
		List<AdoptionRequest> mockRequests = new ArrayList<>();
		AdoptionRequest request1 = new AdoptionRequest();
		request1.setStatus("Pending");
		mockRequests.add(request1);

		AdoptionRequest request2 = new AdoptionRequest();
		request2.setStatus("Approved");
		mockRequests.add(request2);

		// Mock the behavior of adoptionRequestRepository.findAll to return the list of
		// mock requests
		when(adoptionRequestRepository.findAll()).thenReturn(mockRequests);

		// Call the getAllRequests method and assert the returned list of requests
		List<AdoptionRequest> requests = adoptionRequestService.getAllRequests();

		// Verify that the returned list of requests matches the expected values
		assertEquals(2, requests.size());
		assertEquals("Pending", requests.get(0).getStatus());
		assertEquals("Approved", requests.get(1).getStatus());
	}

	@Test
	void testGetRequestsByPetId() throws InvalidCredentialsException {
		// Create a list of mock adoption requests for a specific pet
		List<AdoptionRequest> mockRequests = new ArrayList<>();
		AdoptionRequest request1 = new AdoptionRequest();
		request1.setPetId(1L);
		request1.setStatus("Pending");
		mockRequests.add(request1);

		AdoptionRequest request2 = new AdoptionRequest();
		request2.setPetId(1L);
		request2.setStatus("Approved");
		mockRequests.add(request2);

		// Mock the behavior of adoptionRequestRepository.findByPetId to return the list
		// of mock requests
		when(adoptionRequestRepository.findByPetId(1L)).thenReturn(mockRequests);

		// Call the getRequestsByPetId method and assert the returned list of requests
		List<AdoptionRequest> requests = adoptionRequestService.getRequestsByPetId(1L);

		// Verify that the returned list of requests matches the expected values
		assertEquals(2, requests.size());
		assertEquals("Pending", requests.get(0).getStatus());
		assertEquals("Approved", requests.get(1).getStatus());
	}

	@Test
	void testGetRequestsByUserId() throws InvalidCredentialsException {
		// Create a list of mock adoption requests for a specific user
		List<AdoptionRequest> mockRequests = new ArrayList<>();
		AdoptionRequest request1 = new AdoptionRequest();
		request1.setUserId(1L);
		request1.setStatus("Pending");
		mockRequests.add(request1);

		AdoptionRequest request2 = new AdoptionRequest();
		request2.setUserId(1L);
		request2.setStatus("Approved");
		mockRequests.add(request2);

		// Mock the behavior of adoptionRequestRepository.findByUserId to return the
		// list of mock requests
		when(adoptionRequestRepository.findByUserId(1L)).thenReturn(mockRequests);

		// Call the getRequestsByUserId method and assert the returned list of requests
		List<AdoptionRequest> requests = adoptionRequestService.getRequestsByUserId(1L);

		// Verify that the returned list of requests matches the expected values
		assertEquals(2, requests.size());
		assertEquals("Pending", requests.get(0).getStatus());
		assertEquals("Approved", requests.get(1).getStatus());
	}

}