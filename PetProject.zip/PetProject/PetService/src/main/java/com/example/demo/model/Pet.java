package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
@Table(name = "pet_table")
public class Pet {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Unique identifier for the pet

    @NotBlank(message = "Name is mandatory")
    @Column(nullable = false)
    private String name; // Name of the pet

    @NotBlank(message = "Breed is mandatory")
    @Column(nullable = false)
    private String breed; // Breed of the pet

    @NotBlank(message = "Type is mandatory")
    @Column(nullable = false)
    private String type; // Type of the pet (e.g., Dog, Cat)

    @Min(value = 0, message = "Age must be a non-negative integer")
    @Column(nullable = false)
    private int age; // Age of the pet

    @NotNull(message = "Adoption status is mandatory")
    @Column(nullable = false)
    private boolean isAdopted; // Adoption status of the pet

    @Positive(message = "Price must be a positive integer")
    @Column(nullable = false)
    private int price; // Price of the pet

    // Getters and Setters

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setAdopted(boolean isAdopted) {
        this.isAdopted = isAdopted;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean getIsAdopted() {
        return isAdopted;
    }

    public void setIsAdopted(boolean isAdopted) {
        this.isAdopted = isAdopted;
    }

    // Constructors

    public Pet(Long id, String name, String breed, String type, int age, boolean isAdopted, int price) {
        this.id = id;
        this.name = name;
        this.breed = breed;
        this.type = type;
        this.age = age;
        this.isAdopted = isAdopted;
        this.price = price;
    }

    public Pet() {
        // Default constructor
    }
}