package com.example.demo.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.model.Pet;
import com.example.demo.repository.PetRepository;
import com.example.demo.service.PetServiceImpl;

public class PetServiceImplTest {

    @Mock
    private PetRepository petRepository; // Mocking the PetRepository dependency

    @InjectMocks
    private PetServiceImpl petService; // Injecting the PetServiceImpl with the mocked dependencies

    @BeforeEach
    public void setUp() {
        // Initialize mocks before each test
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddPet() {
        // Create a mock pet
        Pet mockPet = new Pet();
        mockPet.setName("Buddy");
        mockPet.setBreed("Golden Retriever");

        // Mock the behavior of petRepository.save to return the mock pet
        when(petRepository.save(mockPet)).thenReturn(mockPet);

        // Call the addPet method and assert the returned pet's details
        Pet addedPet = petService.addPet(mockPet);

        // Verify that the returned pet's details match the expected values
        assertEquals("Buddy", addedPet.getName());
        assertEquals("Golden Retriever", addedPet.getBreed());
    }

    @Test
    void testDeletePet() {
        // Call the deletePet method
        petService.deletePet(1L);

        // Verify that the petRepository.deleteById method was called with the correct ID
        verify(petRepository).deleteById(1L);
    }

    @Test
    void testGetAllPets() throws InvalidCredentialsException {
        // Create a list of mock pets
        List<Pet> mockPets = new ArrayList<>();
        Pet pet1 = new Pet();
        pet1.setName("Tommy");
        pet1.setBreed("Labrador");
        pet1.setType("Dog");
        pet1.setAge(3);
        pet1.setIsAdopted(false);
        pet1.setPrice(5000);
        mockPets.add(pet1);

        Pet pet2 = new Pet();
        pet2.setName("Kitty");
        pet2.setBreed("Persian");
        pet2.setType("Cat");
        pet2.setAge(2);
        pet2.setIsAdopted(false);
        pet2.setPrice(3000);
        mockPets.add(pet2);

        // Mock the behavior of petRepository.findAll to return the list of mock pets
        when(petRepository.findAll()).thenReturn(mockPets);

        // Call the getAllPets method and assert the returned list of pets
        List<Pet> pets = petService.getAllPets();

        // Verify that the returned list of pets matches the expected values
        assertEquals(2, pets.size());
        assertEquals("Tommy", pets.get(0).getName());
        assertEquals("Kitty", pets.get(1).getName());
    }
}