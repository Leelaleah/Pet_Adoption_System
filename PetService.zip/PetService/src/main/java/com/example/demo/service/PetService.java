package com.example.demo.service;

import java.util.List;

import com.example.demo.model.AdoptionRequestDTO;
import com.example.demo.model.Pet;

public interface PetService {
	Pet addPet(Pet pet);

	Pet updatePet(Long id, Pet petDetails);

	void deletePet(Long id);

	List<Pet> getAllPets();

	Pet getPetById(Long id);

	Pet changeIsAdoptedStatus(Long adoptionId);

	List<AdoptionRequestDTO> getAdoptionRequestsForPet(Long petId);
}
