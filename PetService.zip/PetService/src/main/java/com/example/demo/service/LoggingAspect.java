package com.example.demo.service;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import ch.qos.logback.classic.Logger;

@Aspect
@Component
public class LoggingAspect {
	private static final Logger logger = (Logger) LoggerFactory.getLogger(LoggingAspect.class);

	@Before("execution(* com.example.demo.service.UserServiceImpl.registerUser(..))")
	public void logBeforeRegisterUser(JoinPoint joinPoint) {
		logger.info(
				"Entering method: " + joinPoint.getSignature().getName() + " with arguments: " + joinPoint.getArgs());
	}

	@AfterReturning(pointcut = "execution(* com.example.demo.service.UserServiceImpl.registerUser(..))", returning = "result")
	public void logAfterRegisterUser(JoinPoint joinPoint, Object result) {
		logger.info("Exiting method: " + joinPoint.getSignature().getName() + " with result: " + result);
	}

	@Before("execution(* com.example.demo.service.UserServiceImpl.loginUser(..))")
	public void logBeforeLoginUser(JoinPoint joinPoint) {
		logger.info(
				"Entering method: " + joinPoint.getSignature().getName() + " with arguments: " + joinPoint.getArgs());
	}

	@AfterReturning(pointcut = "execution(* com.example.demo.service.UserServiceImpl.loginUser(..))", returning = "result")
	public void logAfterLoginUser(JoinPoint joinPoint, Object result) {
		logger.info("Exiting method: " + joinPoint.getSignature().getName() + " with result: " + result);
	}
}
