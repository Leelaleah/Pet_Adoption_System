package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.client.AdoptionRequestClient;
import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.model.AdoptionRequestDTO;
import com.example.demo.model.Pet;
import com.example.demo.repository.PetRepository;

@Service
public class PetServiceImpl implements PetService {

	@Autowired
	private PetRepository petRepository;

	@Autowired
	private AdoptionRequestClient adoptionRequestClient;

	@Override
	public Pet addPet(Pet pet) {
		return petRepository.save(pet);
	}

	@Override
	public Pet updatePet(Long id, Pet petDetails) {
		Optional<Pet> petOptional = petRepository.findById(id);
		if (petOptional.isPresent()) {
			Pet pet = petOptional.get();
			pet.setName(petDetails.getName());
			pet.setBreed(petDetails.getBreed());
			pet.setType(petDetails.getType());
			pet.setAge(petDetails.getAge());
			pet.setIsAdopted(petDetails.getIsAdopted());
			return petRepository.save(pet);
		} else {
			throw new RuntimeException("Pet not found with id: " + id);
		}
	}

	@Override
	public void deletePet(Long id) {
		petRepository.deleteById(id);
	}

	@Override
	public List<Pet> getAllPets() throws InvalidCredentialsException{
		return petRepository.findAll();
	}

	@Override
	public Pet getPetById(Long id) throws InvalidCredentialsException{
		return petRepository.findById(id).orElseThrow(() -> new RuntimeException("Pet not found with id: " + id));
	}

	@Override
	public Pet changeIsAdoptedStatus(Long adoptionId) {
		return null;

	}

	@Override
	public List<AdoptionRequestDTO> getAdoptionRequestsForPet(Long petId) throws InvalidCredentialsException{
		return adoptionRequestClient.getRequestsByPetId(petId);
	}
}
