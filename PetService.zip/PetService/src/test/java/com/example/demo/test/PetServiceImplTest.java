package com.example.demo.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.model.Pet;
import com.example.demo.repository.PetRepository;
import com.example.demo.service.PetServiceImpl;

public class PetServiceImplTest {

	@Mock
	private PetRepository petRepository;

	@InjectMocks
	private PetServiceImpl petService;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testAddPet() {
		Pet mockPet = new Pet();
		mockPet.setName("Buddy");
		mockPet.setBreed("Golden Retriever");

		when(petRepository.save(mockPet)).thenReturn(mockPet);

		Pet addedPet = petService.addPet(mockPet);

		assertEquals("Buddy", addedPet.getName());
		assertEquals("Golden Retriever", addedPet.getBreed());
	}
}
