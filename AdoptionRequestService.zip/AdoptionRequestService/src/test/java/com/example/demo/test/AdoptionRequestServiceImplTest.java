package com.example.demo.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.model.AdoptionRequest;
import com.example.demo.repository.AdoptionRequestRepository;
import com.example.demo.service.AdoptionRequestServiceImpl;

public class AdoptionRequestServiceImplTest {

	@Mock
	private AdoptionRequestRepository adoptionRequestRepository;

	@InjectMocks
	private AdoptionRequestServiceImpl adoptionRequestService;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testAddAdoptionRequest() {
		AdoptionRequest mockRequest = new AdoptionRequest();
		mockRequest.setPetId(1L);
		mockRequest.setUserId(1L);

		when(adoptionRequestRepository.save(mockRequest)).thenReturn(mockRequest);

		AdoptionRequest addedRequest = adoptionRequestService.addAdoptionRequest(mockRequest, 1L, 1L);

		assertEquals(1L, addedRequest.getPetId());
		assertEquals(1L, addedRequest.getUserId());
	}
}