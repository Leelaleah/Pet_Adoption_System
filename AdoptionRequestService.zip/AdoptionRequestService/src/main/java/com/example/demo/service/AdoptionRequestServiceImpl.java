package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.model.AdoptionRequest;
import com.example.demo.repository.AdoptionRequestRepository;

@Service
public class AdoptionRequestServiceImpl implements AdoptionRequestService {

	@Autowired
	private AdoptionRequestRepository adoptionRequestRepository;

	@Override
	public AdoptionRequest addAdoptionRequest(AdoptionRequest request, Long petId, Long userId) {
		request.setPetId(petId);
		request.setUserId(userId);
		return adoptionRequestRepository.save(request);
	}

	@Override
	public AdoptionRequest updateAdoptionRequest(Long id, AdoptionRequest requestDetails) {
		AdoptionRequest request = getRequestById(id);
		request.setStatus(requestDetails.getStatus());
		return adoptionRequestRepository.save(request);
	}

	@Override
	public void deleteAdoptionRequest(Long id) {
		adoptionRequestRepository.deleteById(id);
	}

	@Override
	public List<AdoptionRequest> getAllRequests() throws InvalidCredentialsException {
		return adoptionRequestRepository.findAll();
	}

	@Override
	public List<AdoptionRequest> getRequestsByPetId(Long petId) throws InvalidCredentialsException {
		return adoptionRequestRepository.findByPetId(petId);
	}

	@Override
	public List<AdoptionRequest> getRequestsByUserId(Long userId) throws InvalidCredentialsException {
		return adoptionRequestRepository.findByUserId(userId);
	}

	@Override
	public AdoptionRequest getRequestById(Long id) throws InvalidCredentialsException {
		return adoptionRequestRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Adoption request not found"));
	}
}
