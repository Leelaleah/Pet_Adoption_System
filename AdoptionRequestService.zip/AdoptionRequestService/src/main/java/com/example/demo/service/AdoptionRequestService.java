package com.example.demo.service;

import java.util.List;

import com.example.demo.model.AdoptionRequest;

public interface AdoptionRequestService {
	AdoptionRequest addAdoptionRequest(AdoptionRequest request, Long petId, Long userId);

	AdoptionRequest updateAdoptionRequest(Long id, AdoptionRequest requestDetails);

	void deleteAdoptionRequest(Long id);

	List<AdoptionRequest> getAllRequests();

	List<AdoptionRequest> getRequestsByPetId(Long petId);

	List<AdoptionRequest> getRequestsByUserId(Long userId);

	AdoptionRequest getRequestById(Long id);
}
