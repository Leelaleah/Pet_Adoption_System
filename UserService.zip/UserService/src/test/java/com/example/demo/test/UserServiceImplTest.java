package com.example.demo.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.model.LoginRequest;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserServiceImpl;

public class UserServiceImplTest {

	@Mock
	private UserRepository userRepository;

	@InjectMocks
	private UserServiceImpl userService;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testLoginUser() {
		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setUsername("john");
		loginRequest.setPassword("password");

		User mockUser = new User();
		mockUser.setUsername("john");
		mockUser.setPassword("password");

		when(userRepository.findByUsername("john")).thenReturn(Optional.of(mockUser));

		User loggedInUser = userService.loginUser(loginRequest);

		assertEquals("john", loggedInUser.getUsername());
		assertEquals("password", loggedInUser.getPassword());
	}

	
}