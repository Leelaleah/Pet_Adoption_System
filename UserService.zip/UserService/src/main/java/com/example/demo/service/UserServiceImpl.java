package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.client.AdoptionRequestClient;
import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.model.AdoptionRequestDTO;
import com.example.demo.model.LoginRequest;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public User registerUser(User user) {
		return userRepository.save(user);
	}

	@Autowired
	private AdoptionRequestClient adoptionRequestClient;

	@Override
	public User loginUser(LoginRequest loginRequest) {
		Optional<User> user = userRepository.findByUsername(loginRequest.getUsername());
		if (user.isEmpty() || !user.get().getPassword().equals(loginRequest.getPassword())) {
			throw new InvalidCredentialsException("Invalid username or password");
		}
		return user.get();
	}

	@Override
	public User getUserById(Long id) throws InvalidCredentialsException {
		return userRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("User not found"));
	}

	@Override
	public User updateUser(Long id, User updatedUser) {
		User user = getUserById(id);

		if (updatedUser.getUsername() != null) {
			user.setUsername(updatedUser.getUsername());
		}
		if (updatedUser.getEmail() != null) {
			user.setEmail(updatedUser.getEmail());
		}
		if (updatedUser.getPassword() != null) {
			user.setPassword(updatedUser.getPassword());
		}
		return userRepository.save(user);
	}

	@Override
	public List<AdoptionRequestDTO> getAdoptionRequestsForUser(Long userId) throws InvalidCredentialsException {
		return adoptionRequestClient.getRequestsByUserId(userId);
	}

}
